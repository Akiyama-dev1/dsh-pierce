# Pierce

手机端提示词接管插件（DeepSeek Harness / DSH）。零构建、幂等、原子写。

- 版本：0.1.0
- 宿主：`inject: ["systemPrompt"]`，只挂一个 section（`pierce:core`，order 10250）
- 面板：`shell.overlay` 悬浮胶囊 + `settings.section` 设置行，共用一张抽屉

## 结构

```
package.json          dsh.bundle.patch + dsh.client
cordis.patch.yml      只改 system-prompt 的 config，不 insert 本体
lib/index.js          生命周期、段落注册、4+1 条 HTTP 路由
lib/store.js          状态真源：原子写 + 环形备份 + 目录白名单
lib/engine.js         变量插值、chatml 剥壳、组装
lib/presets.js        三档提示词（轻 / 中 / 全）
client.js             单文件 UI（window.__ModuleLoader__，React 18，无打包）
presets/legacy-purge.md  purge 遗留提示词（25KB，素材）
```

## 接口

| 方法 | 路径 | 作用 |
|---|---|---|
| GET | /dsh-pierce/state | 快照 + 注入字符数 + 诊断 |
| POST | /dsh-pierce/set | 改配置，立即重挂段落 |
| POST | /dsh-pierce/preview | 取当前档位全文 |
| POST | /dsh-pierce/reset | 回默认 |
| GET/POST | /dsh-pierce/hello | 面板挂载探针（clientHits） |

## 稳定性约束（写进代码的，不是口号）

1. `inject` 只声明 `systemPrompt` —— 可选服务塞进 inject 会让 Cordis 空等
2. 自己的 patch 里不 insert 本体 —— 二次 insert 即 already queued
3. apply 全程 try/catch，失败只记 lastError，不断启动链
4. 段落注册带 disposer，重复 apply 先撤后挂
5. 写盘 tmp+rename，环形备份 5 份
6. store 目录只认家目录内路径 —— 本机 `mkdirSync('/proc/x')` 会挂死
7. client 顶层 try/catch + ErrorBoundary，slots 缺失只降级

## 排错

- 胶囊没出现：刷新页面（客户端 bundle 需重新加载）
- 状态显示「已开启 · 未落位」：看面板底部诊断里的 `lastError`
- 想彻底停掉：面板主开关关掉，或 profile 里把 `enabled: false`
- 状态文件：`~/.dsh/pierce/store.json`（含 `.bak` 环形备份）

## 回滚

profile 的 `cordis.patch.yml` / `package.json` 都留了 `.bak-pierce-<时间戳>`。
purge 的完整备份在 `/storage/emulated/0/君/_backup/`。
